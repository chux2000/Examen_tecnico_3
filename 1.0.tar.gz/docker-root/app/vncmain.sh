#!/bin/bash
echo 'This is a dummy foreground process'
tail -n0 -f $0
xtern
firefox google.com &
